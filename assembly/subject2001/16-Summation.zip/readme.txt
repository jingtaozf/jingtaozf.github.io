Summation:
	This is a demo which demonstrates how to use exception filters and exception handlers to recover gracefully from a stack overflow. 

File included are:
	Summation.exe    the demo
	Summation.asm	 source file
	Summation.inc    include file
	Summation.rc 	 resource file
	Summation.ico    icon file
	Seh.inc          SEH macro file
	make.bat	 Make file
	readme.txt	 this file
	
Any Problem,please post here:
	jingtaozf@hotmail.com

http://smallwaves.yeah.net(Chinese Version)
http://www.jingtao.org    (English Version)
smallwaves.
2001.12.19