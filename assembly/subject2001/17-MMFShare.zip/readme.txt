MMFShare:
	This demo demonstrates how to use memory-mapped files to transfer data among two or more separate processes.

File included are
	MMFShare.exe	the demo
	MMFShare.asm	source file
	MMFShare.rc	source file
	MMFShare.ico	icon file
	make.bat	Make file
	readme.txt	this file

Any Problem,please post here:
	jingtaozf@hotmail.com

http://smallwaves.yeah.net(Chinese Version)
http://www.jingtao.org    (English Version)
2001.12.19
Smallwaves
