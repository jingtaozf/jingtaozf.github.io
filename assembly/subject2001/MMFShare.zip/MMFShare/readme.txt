MMFShare:
	This is a demo which show how to use "memory mapping file" to share data between different processes.

File included are
	MMFShare.exe	the demo
	MMFShare.asm	source file
	MMFShare.rc	source file
	make.bat	Make file
	readme.txt	this file
Any problem,please post here:
	jingtaozf@hotmail.com
http://smallwaves.yeah.net(Chinese)
http://www.jingtao.org    (English)
2001.11.26
Smallwaves
