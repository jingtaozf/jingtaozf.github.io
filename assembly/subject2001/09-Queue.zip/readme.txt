ErrorShow:
	This  demo  demonstrates how to uses a mutex and a semaphore to control a queue of data elements.

Files Included are:
	CQueue.asm	Class file
	CQueue.html	describe for CQueue class.

	Queue.exe	the demo
	Queue.asm	source file
	Queue.rc	resource file
	Queue.ico	icon file
	Make.bat	Make file
	readme.txt	this file 

Any Problem,please post here:
	jingtaozf@hotmail.com

http://smallwaves.yeah.net(Chinese Version)
http://www.jingtao.org    (English Version)

Smallwaves
2002.2.4

