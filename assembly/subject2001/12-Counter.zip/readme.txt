Counter:
	This demo shows how to implement background processing using fibers.

Files included are:
	Counter.exe	the demo
	Counter.asm	source file
	Counter.inc	include file
	Counter.rc	resource file
	Counter.ico	icon file
	make.bat	make file
	readme.txt	this file

Any Problem,please post here:
	jingtaozf@hotmail.com

http://smallwaves.yeah.net(Chinese Version)
http://www.jingtao.org    (English Version)
2001.12.27
Smallwaves
	