CopyData:
	This  demo  demonstrates how to use the WM_COPYDATA message to send a block of data from one application to another.

Files included are:
	CopyData.exe	the demo
	CopyData.asm	source file
	CopyData.rc	source file
	Make.bat	Make file
	readme.txt	this file

Any Problem,please post here:
	jingtaozf@hotmail.com

http://smallwaves.yeah.net(Chinese Version)
http://www.jingtao.org    (English Version)
2001.12.19
Smallwaves
