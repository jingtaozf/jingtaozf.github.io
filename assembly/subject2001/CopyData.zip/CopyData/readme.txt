CopyData:
	This is a demo which show how to use message "WM_COPYDATA" to translater data between different Processes.

File included are:
	CopyData.exe	the demo
	CopyData.asm	source file
	CopyData.rc	source file
	Make.bat	Make file

Any Problem,please post here:
	jingtaozf@hotmail.com
http://smallwaves.yeah.net(Chinese Version)
http://www.jingtao.org    (English Version)
2001.12.19
Smallwaves
