Handshake:
	This is a demo whick show how to use auto-reset event.

File included are:
	Handshake.exe	the demo
	Handshake.asm	source file
	Handshake.rc	source file
	Make.bat	Make file
	readme.txt	this file
Any Problem,please post here:
	jingtaozf@hotmail.com
http://smallwaves.yeah.net(Chinese)
http://www.jingtao.org    (English)
2001.12.12