//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ProcessInfo.rc
//
#define IDD_PROCESSINFO                 101
#define IDR_PROCESSINFO                 102
#define IDI_PROCESSINFO                 103
#define IDC_PROCESSMODULELIST           1000
#define IDC_RESULTS                     1011
#define IDC_MODULEHELP                  1014
#define ID_PROCESSES                    40001
#define ID_MODULES                      40002
#define ID_VMMAP                        40006

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40007
#define _APS_NEXT_CONTROL_VALUE         1016
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
