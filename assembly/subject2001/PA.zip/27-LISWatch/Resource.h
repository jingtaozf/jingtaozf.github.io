//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by LISWatch.rc
//
#define IDD_LISWATCH                    101
#define IDC_EYES                        101
#define IDI_LISWATCH                    102
#define IDC_WNDFOCUS                    1000
#define IDC_WNDACTIVE                   1001
#define IDC_WNDFOREGRND                 1002
#define IDC_THREADID                    1003
#define IDC_WNDCAPTURE                  1004

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
