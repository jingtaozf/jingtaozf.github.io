/******************************************************************************
Module:  WaitForMultExp.h
Notices: Copyright (c) 2000 Jeffrey Richter
******************************************************************************/


#pragma once


///////////////////////////////////////////////////////////////////////////////


DWORD WINAPI WaitForMultipleExpressions(DWORD nExpObjects, 
   CONST HANDLE* phExpObjects, DWORD dwMilliseconds);


//////////////////////////////// End of File //////////////////////////////////
