SchedLab:
	This demo lets you experiment with process priority classes and relative thread priorities to see their effect on the system's overall performance.

Files included are:
	SchedLab.exe	the demo
	SchedLab.asm	source file
	SchedLab.inc	include file
	SchedLab.rc	resource file
	SchedLab.ico	icon file
	make.bat	make file
	readme.txt	this file

Any Problem,please post here:
	jingtaozf@hotmail.com

http://smallwaves.yeah.net(Chinese Version)
http://www.jingtao.org    (English Version)
2001.12.27
Smallwaves
