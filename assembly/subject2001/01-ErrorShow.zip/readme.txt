ErrorShow:
	This  demo  demonstrates how to get the text description for an error code. 

Files Included are:
	ErrorShow.exe	the demo
	ErrorShow.asm	source file
	ErrorShow.rc	resource file
	ErrorShow.ico	icon file
	Make.bat	Make file
	readme.txt	this file 

Any Problem,please post here:
	jingtaozf@hotmail.com

http://smallwaves.yeah.net(Chinese Version)
http://www.jingtao.org    (English Version)

Smallwaves
2001.12.27

