FileRev:
	This  demo  demonstrates how to use memory-mapped files to reverse the contents of an ANSI or a Unicode text file. 

Files Included are:
	FileRev.exe	the demo
	FileRev.asm	source file
	FileRev.rc	resource file
	FileRev.ico	icon file
	Make.bat	Make file
	readme.txt	this file 

Any Problem,please post here:
	jingtaozf@hotmail.com

http://smallwaves.yeah.net(Chinese Version)

Smallwaves
2002.2.4

