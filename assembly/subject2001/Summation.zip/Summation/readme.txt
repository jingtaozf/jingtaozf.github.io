Summation:
	This is a demo which show how to use "SEH"(Structured Exception Handle) and SEH Filter to retrieve from a "stack overflow".
File included are:
	Summation.exe    the demo
	Summation.asm	 source file
	Summation.inc    include file
	Summation.rc 	 resource file
	Summation.ico    icon file
	Seh.inc          SEH macro file
	make.bat	 Make file
	readme.txt	 this file
	
Any Problem,please post here:
	jingtaozf@hotmail.com
http://smallwaves.yeah.net(Chinese Version)
http://www.jingtao.org    (English Version)
2001.12.19