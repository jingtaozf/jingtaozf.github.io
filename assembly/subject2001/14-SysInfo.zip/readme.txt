SysInfo:
	This demo is a simple program that calls GetSystemInfo and displays the information returned in the SYSTEM_INFO structure.

Files Included are:
	SysInfo.exe	the demo
	SysInfo.asm	source file
	SysInfo.rc	resource file
	SysInfo.ico	icon file
	Make.bat	Make file
	readme.txt	this file 

Any Problem,please post here:
	jingtaozf@hotmail.com

http://smallwaves.yeah.net(Chinese Version)
http://www.jingtao.org    (English Version)

Smallwaves
2002.2.6

