AppInst:
	This demo shows how an application can know how many instances of itself are running at any one time

Files included are
	AppInst.exe	the demo
	AppInst.asm	source file
	AppInst.rc	source file
	AppInst.ico	icon file
	Make.bat	Make file
	readme.txt	this file

Any Problem,please post here:
	jingtaozf@hotmail.com

http://smallwaves.yeah.net(Chinese Version)
http://www.jingtao.org    (English Version)
smallwaves.
2001.12.19
Smallwaves