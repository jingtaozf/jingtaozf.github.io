LISWatch(Local Input State Laboratory):
	This demo is a laboratory that allows you to experiment with local input states. 

Files Included are:
	LISWatch.exe	the demo
	LISWatch.asm	source file
	LISWatch.rc	resource file
	LISWatch.ico	icon file
	Eyes.cur	cursor file
	Make.bat	Make file
	readme.txt	this file 

Any Problem,please post here:
	jingtaozf@hotmail.com

http://smallwaves.yeah.net(Chinese Version)
http://www.jingtao.org    (English Version)

Smallwaves
2002.2.5

