Handshake:
	This  demo shows how to use auto-reset event.

File included are:
	Handshake.exe	the demo
	Handshake.asm	source file
	Handshake.rc	source file
	Handshake.ico	icon file
	Make.bat	Make file
	readme.txt	this file

Any Problem,please post here:
	jingtaozf@hotmail.com

http://smallwaves.yeah.net(Chinese Version)
http://www.jingtao.org    (English Version)
2001.12.19
Smallwaves