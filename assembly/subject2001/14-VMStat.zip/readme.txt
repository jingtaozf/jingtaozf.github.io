VMStat:
	This demo shows how to get Virtual Memory Status 
using "GlobalMemoryStatus".

Files included are:
	VMStat.exe	the demo
	VMStat.asm	source file
	VMStat.inc	include file
	VMStat.rc	resource file
	VMStat.ico	icon file
	make.bat	make file
	readme.txt	this file

Any Problem,please post here:
	jingtaozf@hotmail.com

http://smallwaves.yeah.net(Chinese Version)
http://www.jingtao.org    (English Version)
2001.12.27
Smallwaves
