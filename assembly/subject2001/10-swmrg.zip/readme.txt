SWMRG: (The Single Writer/Multiple Reader Guard) 
	This demo shows how to solve the basic synchronization problem commonly referred to as a single-writer/multiple-readers scenario.

Files included are:
	CSWMRG.asm	class file
	CSWMRG.html	describe about CSWMRG class
	SWMRG.rc	resource file
	SWMRG.ico	icon file
	
	SWMRGTest.exe	Test exe file
	SWMRGTest.asm	Test source file
	SWMRGTest.inc	Test include file	
	make.bat	make file
	readme.txt	this file

Any Problem,please post here:
	jingtaozf@hotmail.com

http://smallwaves.yeah.net(Chinese Version)
http://www.jingtao.org    (English Version)
2001.12.27
Smallwaves
			