MemReset:
	This demo shows how to change the protection attributes associated with a page or pages of committed physical storage.

Files included are:
	MemReset.exe	the demo
	MemReset.asm	source file
	MemReset.inc	include file
	MemReset.rc	resource file
	MemReset.ico	icon file
	make.bat	make file
	readme.txt	this file

Any Problem,please post here:
	jingtaozf@hotmail.com

http://smallwaves.yeah.net(Chinese Version)
http://www.jingtao.org    (English Version)
2001.12.27
Smallwaves
