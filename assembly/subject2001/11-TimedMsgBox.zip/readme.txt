TimeMsgBox:
	This demo shows how to use the thread pool's timer functions to implement a message box that automatically closes if the user doesn't respond within a certain amount of time. 

Files Included are:
	TimeMsgBox.exe	the demo
	TimeMsgBox.asm	source file
	TimeMsgBox.rc	resource file
	TimeMsgBox.ico	icon file
	Make.bat	Make file
	readme.txt	this file 

Any Problem,please post here:
	jingtaozf@hotmail.com

http://smallwaves.yeah.net(Chinese Version)
http://www.jingtao.org    (English Version)

Smallwaves
2001.2.5

