AppInst:
	This is a demo which show how to use shared section in PE file to share data between different Application Instances.

File included are
	AppInst.exe	the demo
	AppInst.asm	source file
	AppInst.rc	source file
	Make.bat	Make file
	readme.txt	this file

Any Problem,please post here:
	jingtaozf@hotmail.com
http://smallwaves.yeah.net(Chinese Version)
http://www.jingtao.org    (English Version)
2001.12.19
Smallwaves