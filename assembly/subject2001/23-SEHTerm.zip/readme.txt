SEHTerm:
	This demo demonstrates how termination handlers work.

File included are:
	SEHTerm.exe	the demo 
	SEHTerm.asm	Source file
	SEHTerm.inc 	include file
	SEHTerm.rc	resource file
	SEHTerm.ico	icon file
	SEH.inc		SEH macro file
	make.bat	Make file
	readme.txt	this file
	
Any Problem,please post here:
	jingtaozf@hotmail.com

http://smallwaves.yeah.net(Chinese Version)
http://www.jingtao.org    (English Version)
smallwaves.
2001.12.19