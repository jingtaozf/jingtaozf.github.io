/*
*   $Id: readtags.h,v 1.1.1.1 2001/12/25 22:24:43 corinna Exp $
*
*   Copyright (c) 1996-2001, Darren Hiebert
*
*   This source code is released for the public domain.
*
*   This file defines the public interface for looking up tag entries in tag
*   files.
*
*   The functions defined in this interface are intended to provide tag file
*   support to a software tool. The tag lookups provided are sufficiently fast
*   enough to permit opening a sorted tag file, searching for a matching tag,
*   then closing the tag file each time a tag is looked up (search times are
*   on the order of milliseconds, even for huge tag files). This is the
*   recommended use of this library for most tool applications. Adhering to
*   this approach permits a user to regenerate a tag file at will without the
*   tool needing to detect and resynchronize with changes to the tag file.
*/

/*
*  MACROS
*/

/* Options for tagFind() */
#define TAG_FULLMATCH     0x0
#define TAG_PARTIALMATCH  0x1
#define TAG_OBSERVECASE   0x0
#define TAG_IGNORECASE    0x2

/*
*  DATA DECLARATIONS
*/

typedef enum { TagFailure = 0, TagSuccess = 1 } tagResult;

struct sTagFile;

typedef struct sTagFile tagFile;

/* This structure contains information about the tag file. */
typedef struct {

	    /* information about the structure of the tag file */
	struct {
		    /* format of tag file (1 = original, 2 = extended) */
		short format;

		    /* is the tag file sorted? (0 = unsorted, 1 = sorted) */
		short sorted;
	} file;


	    /* information about the program which created this tag file */
	struct {
		    /* name of author of generating program (may be null) */
		const char *author;

		    /* name of program (may be null) */
		const char *name;

		    /* URL of distribution (may be null) */
		const char *url;

		    /* program version (may be null) */
		const char *version;
	} program;

} tagFileInfo;

/* This structure contains information about an extension field for a tag.
 * These exist at the end of the tag in the form "key:value").
 */
typedef struct {

	    /* the key of the extension field */
	const char *key;

	    /* the value of the extension field (may be an empty string) */
	const char *value;

} tagExtensionField;

/* This structure contains information about a specific tag. */
typedef struct {

	    /* name of tag */
	const char *name;

	    /* path of source file containing definition of tag */
	const char *file;

	    /* address for locating tag in source file */
	struct {
		    /* pattern for locating source line
		     * (may be NULL if not present) */
		const char *pattern;

		    /* line number in source file of tag definition
		     * (may be zero if not known) */
		unsigned long lineNumber;
	} address;

	    /* kind of tag (may by name, character, or NULL if not known) */
	const char *kind;

	    /* is tag of file-limited scope? */
	short fileScope;

	    /* miscellaneous extension fields */
	struct {
		    /* number of entries in `list' */
		unsigned short count;

		    /* list of key value pairs */
		tagExtensionField *list;
	} fields;

} tagEntry;


/*
*  FUNCTION PROTOTYPES
*/

/*
*  This function must be called before calling other functions in this
*  library. It is passed the path to the tag file to read and, optionally, a
*  pointer to a structure to populate with information about the tag file,
*  which may be null. If successful, the function will return a handle which
*  must be supplied to other calls to read information from the tag file.
*/
extern tagFile *tagsOpen (const char *filePath, tagFileInfo *info);

/*
*  This function allows the client to override the normal automatic detection
*  of whether a tag file is sorted or not. Tag files in the new extended
*  format contain a key indicating whether or not they are sorted. However,
*  tag files in the original format do not contain such a key even when
*  sorted, preventing this library from taking advantage of fast binary
*  lookups. If the client knows that such an unmarked tag file is indeed
*  sorted (or not), it can override the automatic detection. Note that
*  incorrect lookup results will result if a tag file is marked as sorted
*  when it actually is not. The function will return TagSuccess if called on
*  an open tag file or TagFailure if not.
*/
extern tagResult tagsSetSorted (tagFile *file, int sorted);

/*
*  Step sequentially through each line of the tag file. It is passed the
*  handle to an opened tag file and a pointer to a structure which will be
*  populated with information about the next tag file entry, which may be
*  null. The function will return TagSuccess another tag entry is found, or
*  TagFailure if not (i.e. it reached end of file).
*/
extern tagResult tagsNext (tagFile *file, tagEntry *entry);

/*
*  Retrieve the value associated with the extension field for a specified key.
*  It is passed a pointer to a structure already populated with values by a
*  previous call to tagsNext(), tagsFind(), or tagsFindNext(), and a string
*  containing the key of the desired extension field. If no such field of the
*  specified key exists, the function will return null.
*/
extern const char *tagsField (const tagEntry *entry, const char *key);

/*
*  Find the first tag matching `name'. The structure pointed to by `entry'
*  will be populated with information about the tag file entry. If a tag file
*  is sorted using the C locale, a binary search algorithm is used to search
*  the tag file, resulting in very fast tag lookups, even in huge tag files.
*  Various options controlling the matches can be combined by bit-wise or-ing
*  certain values together. The available values are:
*
*    TAG_PARTIALMATCH
*        Tags whose leading characters match `name' will qualify.
*
*    TAG_IGNORECASE
*        Matching will be performed in a case-insenstive manner. Note that
*        this disables binary searches of the tag file.
*
*  The function will return TagSuccess if a tag matching the name is found, or
*  TagFailure if not.
*/
extern tagResult tagsFind (tagFile *file, tagEntry *entry, const char *name, int options);

/*
*  Find the next tag matching the name and options supplied to the most recent
*  call to tagsFind() for the same tag file. The structure pointed to by
*  `entry' will be populated with information about the tag file entry. The
*  function will return TagSuccess if another tag matching the name is found,
*  or TagFailure if not.
*/
extern tagResult tagsFindNext (tagFile *file, tagEntry *entry);

/*
*  Call tagsTerminate() at completion of reading the tag file, which will
*  close the file and free any internal memory allocated. The function will
*  return TagFailure is no file is currently open, TagSuccess otherwise.
*/
extern tagResult tagsClose (tagFile *file);

/* vi:set tabstop=8 shiftwidth=4: */
