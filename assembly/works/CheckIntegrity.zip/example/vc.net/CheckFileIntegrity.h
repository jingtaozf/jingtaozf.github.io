/*;
;Input : filepath to check, NULL if want to check itself.
;Output: -1 if fail; 0 if integrity; >0 failed,value should repaired.
*/

	#ifdef __cplusplus
	extern "C" {
	#endif
	DWORD CheckFileIntegrity(char* lpszFilePath);
	#ifdef __cplusplus
	}
	#endif  
