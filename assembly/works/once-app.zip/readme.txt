 

     The method of these three programs is from Jeffrey Richter 's "Programming Applications for Microsoft Windows,Fourth Edition".
  
  
   	Welcome to visit my personal 
assembly homepage:
		  http://smallwaves.yeah.net; 
	          http://www.jingtao.org
    
      About any problem of them,please 
post here:jingtaozf@hotmail.com
				smallwaves
                       			2001.10.31
                                 From Smallwaves' asm studio.
Note:
   The "Onceapp-3.exe" should be made like this:
      ml /c /Cp /coff Onceapp-3.asm
      link /subsystem:windows /section:share,rws Onceapp-3.obj
  and the other two   should be made like this:
      ml /c /Cp /coff app-name.asm
      link /subsystem:windows app-name.obj
    